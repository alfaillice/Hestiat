/*
 * Puente de arranque de Hestiat.
 *
 * LiteSpeed arranca la app con `require("./.output/server/index.mjs")` desde app.cjs, así que este
 * fichero NO puede usar `await` de nivel superior (require() de un módulo ESM con await de nivel
 * superior falla con ERR_REQUIRE_ASYNC_MODULE). De ahí que se use import() sin await.
 *
 * Carga el entorno y arranca el árbol de Next del docroot.
 */
import { readFileSync } from "node:fs";

const ENV_FILE = process.env.HESTIAT_ENV_FILE ?? "/home/ppxgfdyc/hestiat-app.env";
try {
  for (const linea of readFileSync(ENV_FILE, "utf8").split("\n")) {
    const t = linea.trim();
    if (!t || t.startsWith("#")) continue;
    const eq = t.indexOf("=");
    if (eq <= 0) continue;
    const k = t.slice(0, eq).trim();
    let v = t.slice(eq + 1).trim();
    if (v.length > 1 && (v[0] === '"' || v[0] === "'") && v.endsWith(v[0])) v = v.slice(1, -1);
    if (process.env[k] === undefined) process.env[k] = v;
  }
} catch (e) {
  console.error("[hestiat] entorno:", e.message);
}

process.env.NODE_ENV = process.env.NODE_ENV ?? "production";
process.env.HOST = process.env.HOST ?? process.env.HOSTNAME ?? "0.0.0.0";
process.env.PORT = process.env.PORT ?? process.env.NITRO_PORT ?? "3000";
process.env.HOSTNAME = process.env.HOST;

import("/home/ppxgfdyc/hestiat.com/.next-standalone/server.js").catch((e) => {
  console.error("[hestiat] fallo al arrancar Next:", e && e.message ? e.message : e);
  process.exitCode = 1;
});
