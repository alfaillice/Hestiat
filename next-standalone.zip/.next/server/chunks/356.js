exports.id=356,exports.ids=[356,853],exports.modules={27143:(a,b,c)=>{"use strict";c.d(b,{Dx:()=>i,Ei:()=>p,O8:()=>l,Ql:()=>h,bO:()=>m,iu:()=>o,pool:()=>f,rw:()=>k,ud:()=>j});var d=c(29382);let e={host:process.env.DB_HOST??"localhost",port:Number(process.env.DB_PORT??3306),user:process.env.DB_USER??"",password:process.env.DB_PASSWORD??"",database:process.env.DB_NAME_NEW??"ppxgfdyc_hestiat2",waitForConnections:!0,connectionLimit:8,charset:"utf8mb4_unicode_ci"},f=global.__hestiatPool??d.createPool(e),g={...e,database:process.env.DB_NAME_LEGACY??"ppxgfdyc_hestiat"},h=global.__hestiatPoolLegacy??d.createPool(g);async function i(a={}){let b=(a.q??"").trim(),c=Math.min(Math.max(a.porPagina??12,1),48),d=Math.max(a.pagina??1,1),e=["a.status = 'published'"],g=[];if(""!==b){e.push("(a.title LIKE ? OR a.city LIKE ? OR a.province LIKE ?)");let a=`%${b}%`;g.push(a,a,a)}for(let b of(a.provincia&&(e.push("a.province = ?"),g.push(a.provincia)),"number"==typeof a.precioMin&&Number.isFinite(a.precioMin)&&(e.push("a.price_per_night >= ?"),g.push(a.precioMin)),"number"==typeof a.precioMax&&Number.isFinite(a.precioMax)&&(e.push("a.price_per_night <= ?"),g.push(a.precioMax)),a.servicios??[]))e.push("EXISTS (SELECT 1 FROM accommodation_amenity am WHERE am.accommodation_id = a.id AND am.amenity = ?)"),g.push(b);let h=e.join(" AND "),j="precio_asc"===a.orden?"ORDER BY (a.price_per_night IS NULL), a.price_per_night ASC, a.id ASC":"precio_desc"===a.orden?"ORDER BY (a.price_per_night IS NULL), a.price_per_night DESC, a.id ASC":"ORDER BY (a.price_per_night IS NULL), a.review_count DESC, a.id ASC",[k]=await f.query(`SELECT COUNT(*) AS n FROM accommodation a WHERE ${h}`,g),l=Number(k[0]?.n??0),[m]=await f.query(`SELECT a.id, a.legacy_id, a.slug, a.title, a.city, a.province, a.price_per_night, a.price_type,
            a.capacity, a.bedrooms, a.beds, a.review_score, a.review_count,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation_photo p
              WHERE p.accommodation_id = a.id AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC
              LIMIT 1) AS portada
       FROM accommodation a
      WHERE ${h}
      ${j}
      LIMIT ? OFFSET ?`,[...g,c,(d-1)*c]);return{total:l,pagina:d,porPagina:c,items:m}}async function j(a={},b=300){let c=(await i({...a,pagina:1,porPagina:Math.min(b,48)})).items.map(a=>a.id);if(0===c.length)return[];let d=c.map(()=>"?").join(","),[e]=await f.query(`SELECT id, slug, title, lat, lng, price_per_night, price_type
       FROM accommodation
      WHERE id IN (${d}) AND lat IS NOT NULL AND lng IS NOT NULL`,c);return e}async function k(){let[a]=await f.query(`SELECT province, COUNT(*) AS total FROM accommodation
      WHERE status = 'published' AND province IS NOT NULL AND province <> ''
      GROUP BY province ORDER BY total DESC`),[b]=await f.query(`SELECT am.amenity, COUNT(*) AS total
       FROM accommodation_amenity am
       JOIN accommodation a ON a.id = am.accommodation_id AND a.status = 'published'
      GROUP BY am.amenity ORDER BY total DESC LIMIT 14`),[c]=await f.query("SELECT COALESCE(MAX(price_per_night), 500) AS maximo FROM accommodation WHERE status = 'published' AND price_per_night IS NOT NULL");return{provincias:a,servicios:b,precioMax:Math.ceil(Number(c[0]?.maximo??500))}}async function l(a){let b=/^\d+$/.test(a),[c]=await f.query(`SELECT * FROM accommodation WHERE ${b?"legacy_id = ? OR id = ?":"slug = ?"} LIMIT 1`,b?[Number(a),Number(a)]:[a]),d=c[0];if(!d)return null;let[e]=await f.query(`SELECT id, COALESCE(origin_url, storage_key) AS url, storage_key, alt, width, height, is_primary
       FROM accommodation_photo WHERE accommodation_id = ? ORDER BY is_primary DESC, sort_order ASC LIMIT 12`,[d.id]),[g]=await f.query("SELECT amenity FROM accommodation_amenity WHERE accommodation_id = ? ORDER BY amenity LIMIT 40",[d.id]);return{alojamiento:d,fotos:e,servicios:g}}async function m(a=12){let[b]=await f.query(`SELECT a.province,
            COUNT(*) AS total,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation_photo p
               JOIN accommodation b ON b.id = p.accommodation_id
              WHERE b.province = a.province AND b.status = 'published'
                AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC
              LIMIT 1) AS portada
       FROM accommodation a
      WHERE a.status = 'published' AND a.province IS NOT NULL AND a.province <> ''
      GROUP BY a.province
      ORDER BY total DESC
      LIMIT ?`,[a]);return b}async function n(a,b){let[c]=await f.query(`SELECT COUNT(*) AS total,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation a2
               JOIN accommodation_photo p ON p.accommodation_id = a2.id
              WHERE ${a.replace(/\ba\./g,"a2.")}
                AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC
              LIMIT 1) AS portada
       FROM accommodation a
      WHERE ${a}`,[...b,...b]),d=c[0];return{portada:d?.portada??null,total:Number(d?.total??0)}}async function o(){let a=a=>a.map(a=>"'"+a.replace(/'/g,"''")+"'").join(","),[b,c,d,e]=await Promise.all([n(`a.status='published' AND a.province IN (${a(["Alacant/Alicante","M\xe1laga","Illes Balears","Girona","Barcelona","Val\xe8ncia/Valencia","Tarragona","Cantabria","A Coru\xf1a","Pontevedra","Las Palmas","Santa Cruz de Tenerife","Murcia","C\xe1diz","Huelva","Castell\xf3/Castell\xf3n","Gipuzkoa/Guip\xfazcoa","Bizkaia/Vizcaya"])})`,[]),n(`a.status='published' AND a.province IN (${a(["Asturias","Cantabria","Granada","Segovia","\xc1vila","Navarra","Huesca","Lleida","Girona","Teruel","Cuenca","Ja\xe9n","La Rioja","Palencia","Soria","Le\xf3n"])})`,[]),n("a.status='published' AND (a.title LIKE '%casa%' OR a.title LIKE '%palacio%' OR a.title LIKE '%convento%' OR a.title LIKE '%castillo%' OR a.title LIKE '%monasterio%' OR a.title LIKE '%torre%')",[]),n("a.status='published' AND a.capacity >= 6",[])]);return[{clave:"mar",etiqueta:"Costa y mar",descripcion:"Casas junto al agua",...b},{clave:"montana",etiqueta:"Paisaje de monta\xf1a",descripcion:"Valles y sierras",...c},{clave:"historia",etiqueta:"Arquitectura hist\xf3rica",descripcion:"Casas con historia",...d},{clave:"familias",etiqueta:"Planes en familia",descripcion:"Espacio para todos",...e}]}async function p(a=8){let[b]=await f.query(`SELECT a.id, a.legacy_id, a.slug, a.title, a.city, a.province, a.price_per_night, a.price_type,
            a.capacity, a.bedrooms, a.beds, a.review_score, a.review_count,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation_photo p
              WHERE p.accommodation_id = a.id AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC LIMIT 1) AS portada
       FROM accommodation a
      WHERE a.status = 'published'
      ORDER BY (a.price_per_night IS NULL), a.review_count DESC, a.id ASC
      LIMIT ?`,[a]);return b}},28303:a=>{function b(a){var b=Error("Cannot find module '"+a+"'");throw b.code="MODULE_NOT_FOUND",b}b.keys=()=>[],b.resolve=b,b.id=28303,a.exports=b},51774:(a,b,c)=>{"use strict";c.d(b,{A:()=>f});var d=c(75338),e=c(27143);async function f({q:a,pagina:b,basePath:c,filtros:f}){let{total:g,items:h,porPagina:i}=await (0,e.Dx)({...f??{},q:a,pagina:b}),j=0===g?0:(b-1)*i+1,k=Math.min(b*i,g),l=new URLSearchParams;for(let b of(a&&l.set("q",a),f?.provincia&&l.set("provincia",f.provincia),"number"==typeof f?.precioMin&&l.set("precioMin",String(f.precioMin)),"number"==typeof f?.precioMax&&l.set("precioMax",String(f.precioMax)),f?.servicios??[]))l.append("servicios",b);f?.orden&&l.set("orden",f.orden);let m=a=>{let b=new URLSearchParams(l);return b.set("p",String(a)),`${c}?${b.toString()}`};return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)("form",{className:"search",method:"get",action:c,children:[(0,d.jsx)("input",{name:"q",defaultValue:a,placeholder:"Ciudad, provincia…","aria-label":"Buscar destino"}),(0,d.jsx)("button",{type:"submit",children:"Buscar"})]}),(0,d.jsxs)("p",{className:"count",children:[g.toLocaleString("es-ES")," alojamientos",a?` para \xab${a}\xbb`:"",g>0?` \xb7 mostrando ${j}–${k}`:""]}),0===h.length?(0,d.jsx)("p",{className:"warn",children:"No hay resultados con ese criterio. Prueba con otra ciudad o provincia, o quita el filtro."}):(0,d.jsx)("div",{className:"cards",children:h.map(a=>(0,d.jsxs)("a",{className:"card",href:`/alojamiento/${a.slug}`,children:[a.portada?(0,d.jsx)("img",{src:a.portada,alt:a.title,loading:"lazy"}):(0,d.jsx)("div",{className:"nofoto"}),(0,d.jsxs)("div",{className:"body",children:[(0,d.jsx)("div",{className:"t",children:a.title}),(0,d.jsx)("div",{className:"m",children:[a.city,a.province].filter(Boolean).join(", ")}),(0,d.jsxs)("div",{className:"p",children:[a.price_per_night?`${Number(a.price_per_night).toLocaleString("es-ES")} € / noche`:"Consultar","real"!==a.price_type&&(0,d.jsx)("span",{className:"ref",children:" \xb7 orientativo"})]})]})]},a.id))}),(0,d.jsxs)("nav",{className:"nav",children:[b>1&&(0,d.jsx)("a",{href:m(b-1),children:"← Anterior"}),k<g&&(0,d.jsx)("a",{href:m(b+1),children:"Siguiente →"})]}),(0,d.jsxs)("p",{className:"warn",children:["Datos reales del esquema nuevo (",(0,d.jsx)("code",{children:"accommodation"}),", ",(0,d.jsx)("code",{children:"accommodation_photo"}),"). Los precios se distinguen siempre entre publicados y orientativos, con su fuente."]})]})}}};