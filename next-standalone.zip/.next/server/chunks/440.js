exports.id=440,exports.ids=[440,853],exports.modules={6462:(a,b,c)=>{"use strict";c.d(b,{HW:()=>j,Yt:()=>n,ZT:()=>m,iD:()=>k,sq:()=>l});var d=c(86802),e=c(77598),f=c(27143);let g="hestiat_sesion";async function h(a,b){let c=(0,e.randomBytes)(32).toString("hex"),d=new Date(Date.now()+2592e6);return await f.Ql.query("INSERT INTO usuario_sesion (token, usuario_id, expira_en, user_agent) VALUES (?,?,?,?)",[c,a,d,b?.slice(0,255)??null]),c}async function i(a){(await (0,d.UL)()).set(g,a,{httpOnly:!0,sameSite:"lax",secure:!0,path:"/",maxAge:2592e3})}async function j(){let a;try{let b=await (0,d.UL)();a=b.get(g)?.value}catch{return null}if(!a||64!==a.length)return null;try{let[b]=await f.Ql.query(`SELECT u.id, u.email, u.nombre, u.telefono, u.rol, u.creado_en
         FROM usuario_sesion s
         JOIN usuario u ON u.id = s.usuario_id
        WHERE s.token = ? AND s.expira_en > NOW() AND u.activo = 1 AND u.bloqueado_en IS NULL
        LIMIT 1`,[a]),c=b[0];if(!c)return null;return{id:Number(c.id),email:String(c.email),nombre:c.nombre??null,telefono:c.telefono??null,rol:c.rol,creadoEn:String(c.creado_en)}}catch{return null}}async function k(a){let b=a.email.trim().toLowerCase();if(!b||!a.password)return{ok:!1,error:"Introduce tu correo y tu contrase\xf1a."};let[c]=await f.Ql.query("SELECT id, email, nombre, telefono, rol, password_hash, activo, bloqueado_en FROM usuario WHERE email = ? LIMIT 1",[b]),d=c[0],g={ok:!1,error:"Correo o contrase\xf1a incorrectos."};if(!d)return g;if(1!==Number(d.activo)||d.bloqueado_en)return{ok:!1,error:"Esta cuenta est\xe1 bloqueada. Contacta con soporte."};if(!function(a,b){if(!b)return!1;let c=b.split("$");if(3!==c.length||"scrypt"!==c[0])return!1;let d=c[1],f=Buffer.from(c[2],"hex");if(0===f.length)return!1;try{let b=(0,e.scryptSync)(a,d,f.length);return b.length===f.length&&(0,e.timingSafeEqual)(b,f)}catch{return!1}}(a.password,d.password_hash))return g;let j=await h(Number(d.id),a.userAgent);return await i(j),{ok:!0,usuario:{id:Number(d.id),email:String(d.email),nombre:d.nombre??null,telefono:d.telefono??null,rol:d.rol,creadoEn:""}}}async function l(){let a=await j();return a&&("anfitrion"===a.rol||"admin"===a.rol)?a:null}async function m(){let a=await j();return a&&"admin"===a.rol?a:null}async function n(a,b){let[c]=await f.Ql.query("SELECT COUNT(*) AS c FROM alojamiento_anfitrion WHERE usuario_id = ? AND alojamiento_id = ?",[a,b]);return Number(c[0]?.c??0)>0}},27143:(a,b,c)=>{"use strict";c.d(b,{Dx:()=>i,Ei:()=>p,O8:()=>l,Ql:()=>h,bO:()=>m,iu:()=>o,pool:()=>f,rw:()=>k,ud:()=>j});var d=c(29382);let e={host:process.env.DB_HOST??"localhost",port:Number(process.env.DB_PORT??3306),user:process.env.DB_USER??"",password:process.env.DB_PASSWORD??"",database:process.env.DB_NAME_NEW??"ppxgfdyc_hestiat2",waitForConnections:!0,connectionLimit:8,charset:"utf8mb4_unicode_ci"},f=global.__hestiatPool??d.createPool(e),g={...e,database:process.env.DB_NAME_LEGACY??"ppxgfdyc_hestiat"},h=global.__hestiatPoolLegacy??d.createPool(g);async function i(a={}){let b=(a.q??"").trim(),c=Math.min(Math.max(a.porPagina??12,1),48),d=Math.max(a.pagina??1,1),e=["a.status = 'published'"],g=[];if(""!==b){e.push("(a.title LIKE ? OR a.city LIKE ? OR a.province LIKE ?)");let a=`%${b}%`;g.push(a,a,a)}for(let b of(a.provincia&&(e.push("a.province = ?"),g.push(a.provincia)),"number"==typeof a.precioMin&&Number.isFinite(a.precioMin)&&(e.push("a.price_per_night >= ?"),g.push(a.precioMin)),"number"==typeof a.precioMax&&Number.isFinite(a.precioMax)&&(e.push("a.price_per_night <= ?"),g.push(a.precioMax)),a.servicios??[]))e.push("EXISTS (SELECT 1 FROM accommodation_amenity am WHERE am.accommodation_id = a.id AND am.amenity = ?)"),g.push(b);let h=e.join(" AND "),j="precio_asc"===a.orden?"ORDER BY (a.price_per_night IS NULL), a.price_per_night ASC, a.id ASC":"precio_desc"===a.orden?"ORDER BY (a.price_per_night IS NULL), a.price_per_night DESC, a.id ASC":"ORDER BY (a.price_per_night IS NULL), a.review_count DESC, a.id ASC",[k]=await f.query(`SELECT COUNT(*) AS n FROM accommodation a WHERE ${h}`,g),l=Number(k[0]?.n??0),[m]=await f.query(`SELECT a.id, a.legacy_id, a.slug, a.title, a.city, a.province, a.price_per_night, a.price_type,
            a.capacity, a.bedrooms, a.beds, a.review_score, a.review_count,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation_photo p
              WHERE p.accommodation_id = a.id AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC
              LIMIT 1) AS portada
       FROM accommodation a
      WHERE ${h}
      ${j}
      LIMIT ? OFFSET ?`,[...g,c,(d-1)*c]);return{total:l,pagina:d,porPagina:c,items:m}}async function j(a={},b=300){let c=(await i({...a,pagina:1,porPagina:Math.min(b,48)})).items.map(a=>a.id);if(0===c.length)return[];let d=c.map(()=>"?").join(","),[e]=await f.query(`SELECT id, slug, title, lat, lng, price_per_night, price_type
       FROM accommodation
      WHERE id IN (${d}) AND lat IS NOT NULL AND lng IS NOT NULL`,c);return e}async function k(){let[a]=await f.query(`SELECT province, COUNT(*) AS total FROM accommodation
      WHERE status = 'published' AND province IS NOT NULL AND province <> ''
      GROUP BY province ORDER BY total DESC`),[b]=await f.query(`SELECT am.amenity, COUNT(*) AS total
       FROM accommodation_amenity am
       JOIN accommodation a ON a.id = am.accommodation_id AND a.status = 'published'
      GROUP BY am.amenity ORDER BY total DESC LIMIT 14`),[c]=await f.query("SELECT COALESCE(MAX(price_per_night), 500) AS maximo FROM accommodation WHERE status = 'published' AND price_per_night IS NOT NULL");return{provincias:a,servicios:b,precioMax:Math.ceil(Number(c[0]?.maximo??500))}}async function l(a){let b=/^\d+$/.test(a),[c]=await f.query(`SELECT * FROM accommodation WHERE ${b?"legacy_id = ? OR id = ?":"slug = ?"} LIMIT 1`,b?[Number(a),Number(a)]:[a]),d=c[0];if(!d)return null;let[e]=await f.query(`SELECT id, COALESCE(origin_url, storage_key) AS url, storage_key, alt, width, height, is_primary
       FROM accommodation_photo WHERE accommodation_id = ? ORDER BY is_primary DESC, sort_order ASC LIMIT 12`,[d.id]),[g]=await f.query("SELECT amenity FROM accommodation_amenity WHERE accommodation_id = ? ORDER BY amenity LIMIT 40",[d.id]);return{alojamiento:d,fotos:e,servicios:g}}async function m(a=12){let[b]=await f.query(`SELECT a.province,
            COUNT(*) AS total,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation_photo p
               JOIN accommodation b ON b.id = p.accommodation_id
              WHERE b.province = a.province AND b.status = 'published'
                AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC
              LIMIT 1) AS portada
       FROM accommodation a
      WHERE a.status = 'published' AND a.province IS NOT NULL AND a.province <> ''
      GROUP BY a.province
      ORDER BY total DESC
      LIMIT ?`,[a]);return b}async function n(a,b){let[c]=await f.query(`SELECT COUNT(*) AS total,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation a2
               JOIN accommodation_photo p ON p.accommodation_id = a2.id
              WHERE ${a.replace(/\ba\./g,"a2.")}
                AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC
              LIMIT 1) AS portada
       FROM accommodation a
      WHERE ${a}`,[...b,...b]),d=c[0];return{portada:d?.portada??null,total:Number(d?.total??0)}}async function o(){let a=a=>a.map(a=>"'"+a.replace(/'/g,"''")+"'").join(","),[b,c,d,e]=await Promise.all([n(`a.status='published' AND a.province IN (${a(["Alacant/Alicante","M\xe1laga","Illes Balears","Girona","Barcelona","Val\xe8ncia/Valencia","Tarragona","Cantabria","A Coru\xf1a","Pontevedra","Las Palmas","Santa Cruz de Tenerife","Murcia","C\xe1diz","Huelva","Castell\xf3/Castell\xf3n","Gipuzkoa/Guip\xfazcoa","Bizkaia/Vizcaya"])})`,[]),n(`a.status='published' AND a.province IN (${a(["Asturias","Cantabria","Granada","Segovia","\xc1vila","Navarra","Huesca","Lleida","Girona","Teruel","Cuenca","Ja\xe9n","La Rioja","Palencia","Soria","Le\xf3n"])})`,[]),n("a.status='published' AND (a.title LIKE '%casa%' OR a.title LIKE '%palacio%' OR a.title LIKE '%convento%' OR a.title LIKE '%castillo%' OR a.title LIKE '%monasterio%' OR a.title LIKE '%torre%')",[]),n("a.status='published' AND a.capacity >= 6",[])]);return[{clave:"mar",etiqueta:"Costa y mar",descripcion:"Casas junto al agua",...b},{clave:"montana",etiqueta:"Paisaje de monta\xf1a",descripcion:"Valles y sierras",...c},{clave:"historia",etiqueta:"Arquitectura hist\xf3rica",descripcion:"Casas con historia",...d},{clave:"familias",etiqueta:"Planes en familia",descripcion:"Espacio para todos",...e}]}async function p(a=8){let[b]=await f.query(`SELECT a.id, a.legacy_id, a.slug, a.title, a.city, a.province, a.price_per_night, a.price_type,
            a.capacity, a.bedrooms, a.beds, a.review_score, a.review_count,
            (SELECT COALESCE(p.origin_url, p.storage_key)
               FROM accommodation_photo p
              WHERE p.accommodation_id = a.id AND COALESCE(p.origin_url, p.storage_key) IS NOT NULL
              ORDER BY p.is_primary DESC, p.sort_order ASC LIMIT 1) AS portada
       FROM accommodation a
      WHERE a.status = 'published'
      ORDER BY (a.price_per_night IS NULL), a.review_count DESC, a.id ASC
      LIMIT ?`,[a]);return b}},28303:a=>{function b(a){var b=Error("Cannot find module '"+a+"'");throw b.code="MODULE_NOT_FOUND",b}b.keys=()=>[],b.resolve=b,b.id=28303,a.exports=b}};