/* Activo de coherencia del despliegue de Hestiat. Sin lógica. */
