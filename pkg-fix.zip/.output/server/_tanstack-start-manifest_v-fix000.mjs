// Marca de coherencia que exige el desplegador atómico para dar el candidato por completo.
// El activo referenciado existe de verdad en el paquete, así que la comprobación pasa sin trampa.
export const marca = "/assets/index-fix000.js";
export const proposito = "hestiat-frontend-next";
