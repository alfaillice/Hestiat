exports.id=163,exports.ids=[163],exports.modules={5346:()=>{},5798:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,54160,23)),Promise.resolve().then(c.t.bind(c,31603,23)),Promise.resolve().then(c.t.bind(c,68495,23)),Promise.resolve().then(c.t.bind(c,75170,23)),Promise.resolve().then(c.t.bind(c,77526,23)),Promise.resolve().then(c.t.bind(c,78922,23)),Promise.resolve().then(c.t.bind(c,29234,23)),Promise.resolve().then(c.t.bind(c,12263,23)),Promise.resolve().then(c.bind(c,82146))},16953:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>k,metadata:()=>i});var d=c(75338),e=c(49231),f=c.n(e),g=c(17899),h=c.n(g);let i={title:"Hestiat — Alojamientos con car\xe1cter en toda Espa\xf1a",description:"Encuentra donde quedarte, sin sorpresas y sin comisiones. Busca por ciudad, provincia, c\xf3digo postal o punto de inter\xe9s.",metadataBase:new URL("https://hestiat.com")},j=`
:root{
  --background:oklch(98.8% .005 92); --foreground:oklch(23.5% .021 225); --ink:oklch(18.5% .024 230);
  --card:oklch(100% 0 0); --primary:oklch(41.5% .072 197); --primary-fg:oklch(98.5% .008 190);
  --primary-soft:oklch(94.5% .022 195); --accent:oklch(79.5% .135 74); --accent-fg:oklch(29% .06 62);
  --secondary:oklch(96.2% .008 92); --muted:oklch(95.5% .007 92); --muted-fg:oklch(51.5% .019 232);
  --success:oklch(58% .115 158); --destructive:oklch(55.2% .191 25);
  --border:oklch(90% .008 232); --surface:oklch(97.2% .008 92); --surface-strong:oklch(93.5% .014 92);
  --radio:14px; --radio-pill:9999px;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--background);color:var(--foreground)}
body{font-family:var(--fuente-texto),ui-sans-serif,system-ui,sans-serif;font-size:15.2px;line-height:1.55;-webkit-font-smoothing:antialiased}
h1,h2,h3{font-family:var(--fuente-titulo),ui-sans-serif,system-ui,sans-serif;font-weight:700;letter-spacing:-.02em;line-height:1.12}
a{color:inherit;text-decoration:none} img{display:block;max-width:100%}
.wrap{max-width:1360px;margin:0 auto;padding:0 18px}
/* cabecera */
.cab{border-bottom:1px solid var(--border);background:var(--background);position:sticky;top:0;z-index:40}
.cab-in{display:flex;align-items:center;gap:14px;height:60px}
.marca{font-weight:700;letter-spacing:-.01em;font-size:20px;color:var(--primary);font-family:var(--fuente-titulo)}
.cab-btn{margin-left:auto;border:1px solid var(--border);background:var(--card);border-radius:var(--radio-pill);padding:8px 16px;font:inherit;cursor:pointer}
/* buscador pill */
.buscador{display:flex;align-items:center;gap:6px;background:var(--card);border:1px solid var(--border);border-radius:var(--radio-pill);padding:6px;box-shadow:0 10px 30px rgba(20,40,50,.10);max-width:940px}
.buscador .campo{flex:1;display:flex;flex-direction:column;padding:6px 14px;min-width:0}
.buscador .etq{font-size:11px;font-weight:700;letter-spacing:.06em;color:var(--muted-fg);text-transform:uppercase}
.buscador input{border:0;background:transparent;font:inherit;outline:none;color:var(--ink);width:100%}
.buscador .sep{width:1px;height:28px;background:var(--border)}
.buscador button{background:var(--primary);color:var(--primary-fg);border:0;border-radius:var(--radio-pill);padding:12px 22px;font:inherit;font-weight:700;cursor:pointer;white-space:nowrap}
/* hero */
.hero{position:relative;min-height:420px;display:flex;align-items:flex-end;margin-bottom:26px;overflow:hidden}
.hero img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.hero .velo{position:absolute;inset:0;background:linear-gradient(180deg,rgba(12,30,36,.15) 0%,rgba(12,30,36,.72) 100%)}
.hero .cont{position:relative;width:100%;padding:28px 18px 30px;max-width:1180px;margin:0 auto}
.hero .eyebrow{color:var(--accent);font-weight:700;letter-spacing:.14em;font-size:11.5px;text-transform:uppercase;margin-bottom:8px}
.hero h1{color:#fff;font-size:38px;max-width:22ch;margin-bottom:10px}
.hero p.sub{color:rgba(255,255,255,.9);max-width:54ch;margin-bottom:18px;font-size:14.5px}
.hero .credito{position:absolute;right:14px;bottom:8px;color:rgba(255,255,255,.55);font-size:10.5px}
/* secciones */
.seccion{margin:64px 0}
.seccion-cab{display:flex;align-items:baseline;gap:12px;margin-bottom:4px}
.seccion-cab h2{font-size:24px}
.seccion-cab .mas{margin-left:auto;color:var(--primary);font-weight:600;font-size:13.5px}
.seccion-sub{color:var(--muted-fg);font-size:13.5px;margin-bottom:14px}
/* carrusel */
.carrusel{display:flex;gap:14px;overflow-x:auto;padding-bottom:6px;scrollbar-width:thin}
.carrusel::-webkit-scrollbar{height:6px}.carrusel::-webkit-scrollbar-thumb{background:var(--border);border-radius:9px}
/* tarjetas de estilo */
.estilo{position:relative;display:block;flex:1 1 0;min-width:240px;height:200px;border-radius:var(--radio);overflow:hidden;background:var(--surface-strong)}
.estilo img{width:100%;height:100%;object-fit:cover}
.estilo .velo{position:absolute;inset:0;background:linear-gradient(180deg,transparent 35%,rgba(12,30,36,.75) 100%)}
.estilo .txt{position:absolute;left:14px;bottom:12px;color:#fff}
.estilo .txt b{font-family:var(--fuente-titulo);font-size:16.5px;display:block}
.estilo .txt span{font-size:12.5px;opacity:.85}
/* destinos */
/* 200px: con 1360 de contenedor, 6 columnas de 210 se quedaban a 6px de entrar. */
.destinos{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px}
.destino{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);overflow:hidden}
.destino img{height:110px;width:100%;object-fit:cover;background:var(--surface-strong)}
.destino .d{padding:10px 12px 12px}
.destino b{font-family:var(--fuente-titulo);font-size:15px;display:block}
.destino span{color:var(--muted-fg);font-size:12.5px;font-variant-numeric:tabular-nums}
/* tarjetas de alojamiento */
.rejilla{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:22px}
.aloj{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);overflow:hidden;transition:box-shadow .18s ease,transform .18s ease}
.aloj:hover{box-shadow:0 12px 28px rgba(20,40,50,.12);transform:translateY(-2px)}
/* display:block imprescindible: un <span> ignora la altura y la foto se desborda
   (medido en producci\xf3n: 333px en lugar de 190px, con la rejilla irregular). */
.aloj .foto{display:block;position:relative;height:190px;background:var(--surface-strong)}
.aloj .foto img{width:100%;height:100%;object-fit:cover}
.aloj .fav{position:absolute;top:10px;right:10px;width:32px;height:32px;border-radius:var(--radio-pill);border:0;background:rgba(255,255,255,.9);cursor:pointer}
.aloj .d{padding:11px 13px 14px}
.aloj .t{font-family:var(--fuente-titulo);font-weight:700;font-size:15.5px;line-height:1.25;margin-bottom:2px}
.aloj .m{color:var(--muted-fg);font-size:12.5px}
.aloj .p{margin-top:8px;font-weight:700;font-variant-numeric:tabular-nums}
.aloj .p .ref{color:var(--muted-fg);font-weight:400;font-size:12px}
.precio{font-variant-numeric:tabular-nums}
footer{border-top:1px solid var(--border);margin-top:44px;padding:24px 0;color:var(--muted-fg);font-size:13px}
.aviso{background:var(--secondary);border:1px solid var(--border);border-radius:var(--radio);padding:12px 15px;font-size:13px;color:var(--muted-fg)}
/* busqueda con mapa y filtros */
.busqueda{display:grid;grid-template-columns:minmax(0,1fr) minmax(360px,42%);gap:26px;align-items:start}
.mapa-lado{position:sticky;top:76px}
.filtros{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);padding:14px;margin-bottom:18px;display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.f-campo{display:flex;flex-direction:column;gap:5px}
.f-campo select,.f-campo input{border:1px solid var(--border);border-radius:10px;padding:9px 10px;font:inherit;background:var(--background);color:var(--ink);width:100%}
.f-servicios{grid-column:1/-1;border:0}
.f-chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:6px}
.f-chip{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--border);border-radius:var(--radio-pill);padding:6px 12px;font-size:13.5px;cursor:pointer;background:var(--background)}
.f-chip input{accent-color:var(--primary)}
.f-chip em{color:var(--muted-fg);font-style:normal;font-size:12px}
.f-acciones{grid-column:1/-1;display:flex;align-items:center;gap:14px}
.f-aplicar{background:var(--primary);color:var(--primary-fg);border:0;border-radius:var(--radio-pill);padding:11px 22px;font:inherit;font-weight:700;cursor:pointer}
.f-limpiar{color:var(--muted-fg);font-size:13.5px;text-decoration:underline}
/* marcadores de precio del mapa */
.hx-pin-wrapper{background:none;border:0}
.hx-pin{display:inline-block;transform:translate(-50%,-50%);background:var(--card);border:1.5px solid var(--border);border-radius:var(--radio-pill);padding:4px 10px;font-weight:600;font-size:12.5px;color:var(--ink);font-variant-numeric:tabular-nums;box-shadow:0 3px 10px rgba(20,40,50,.18);white-space:nowrap}
.hx-pin--activo{border-color:var(--accent);box-shadow:0 4px 14px rgba(200,120,0,.30)}
/* paneles: administracion y anfitrion */
.admin{display:grid;grid-template-columns:230px minmax(0,1fr);gap:26px;max-width:1360px;margin:0 auto;padding:22px 18px}
.admin-nav{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);padding:16px;position:sticky;top:76px;align-self:start}
.admin-marca{font-family:var(--fuente-titulo);font-weight:700;font-size:15px;color:var(--primary);margin-bottom:12px}
.admin-nav nav{display:flex;flex-direction:column;gap:2px}
.admin-nav nav a{padding:8px 10px;border-radius:10px;font-size:14.5px}
.admin-nav nav a:hover{background:var(--secondary)}
.admin-sesion{margin-top:16px;padding-top:12px;border-top:1px solid var(--border);font-size:12.5px;word-break:break-all}
.admin-main{min-width:0}
.admin-cab{margin-bottom:16px}
.admin-cab h1{font-size:26px;margin-bottom:4px}
.admin-buscar{display:flex;gap:10px;background:var(--card);border:1px solid var(--border);border-radius:var(--radio);padding:10px;margin-bottom:16px}
.admin-buscar input,.admin-buscar select{border:1px solid var(--border);border-radius:10px;padding:9px 11px;font:inherit;background:var(--background);color:var(--ink)}
.admin-buscar input{flex:1}
.tabla-scroll{overflow-x:auto;background:var(--card);border:1px solid var(--border);border-radius:var(--radio)}
.tabla{width:100%;border-collapse:collapse;font-size:13.5px}
.tabla th{text-align:left;padding:11px 12px;border-bottom:1px solid var(--border);color:var(--muted-fg);font-weight:600;white-space:nowrap;background:var(--surface)}
.tabla td{padding:10px 12px;border-bottom:1px solid var(--border);vertical-align:middle}
.tabla tr:last-child td{border-bottom:0}
.tabla .num{font-variant-numeric:tabular-nums;text-align:right}
.punto{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:7px}
.punto-ok{background:var(--success)}
.punto-off{background:var(--muted-fg)}
.enlace-accion{color:var(--primary);font-weight:600;white-space:nowrap}
.form-edicion{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);padding:18px;display:grid;gap:14px;max-width:620px}
.fila-2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.login{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);padding:20px;display:grid;gap:14px}
/* medios y canales (portado del gestor antiguo) */
.medios,.canales{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);padding:18px}
.medios-cab{margin-bottom:12px}
.medios-cab h2{font-size:19px;margin-bottom:3px}
.medios-subir{display:flex;flex-wrap:wrap;align-items:center;gap:12px;padding:12px;border:1px dashed var(--border);border-radius:var(--radio);margin-bottom:16px}
.medios-subir input[type=file]{font:inherit;font-size:13.5px}
.medios-rejilla{list-style:none;display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:12px}
.medio{position:relative;border:1px solid var(--border);border-radius:var(--radio);overflow:hidden;background:var(--surface)}
.medio img{display:block;width:100%;height:128px;object-fit:cover}
.medio-orden{position:absolute;top:7px;left:7px;background:rgba(15,25,30,.78);color:#fff;font-size:11.5px;font-weight:600;padding:2px 8px;border-radius:var(--radio-pill)}
.medio-acciones{position:absolute;top:6px;right:6px;display:flex;gap:4px}
.medio-acciones button{width:26px;height:26px;border:1px solid var(--border);border-radius:8px;background:var(--card);color:var(--ink);font-size:14px;line-height:1;cursor:pointer}
.medio-acciones button:disabled{opacity:.4;cursor:default}
.medio-acciones .medio-borrar:hover{border-color:var(--destructive);color:var(--destructive)}
.canales-lista{list-style:none;display:grid;gap:12px}
.canal{border:1px solid var(--border);border-radius:var(--radio);padding:13px}
.canal-cab{display:flex;justify-content:space-between;align-items:baseline;gap:12px;flex-wrap:wrap}
.canal-estado{font-size:13px;color:var(--muted-fg)}
.canal-acciones{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}
.canal-acciones input{flex:1;min-width:210px;border:1px solid var(--border);border-radius:10px;padding:8px 11px;font:inherit;font-size:13.5px;background:var(--background);color:var(--ink)}
/* auditoria automatica */
.auditoria{display:grid;gap:16px}
.aud-bloque{background:var(--card);border:1px solid var(--border);border-radius:var(--radio);padding:16px}
.aud-cab{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:4px}
.aud-cab h2{font-size:17px}
.aud-num{font-variant-numeric:tabular-nums;font-weight:700;font-size:19px;color:var(--success)}
.aud-num-aviso{color:var(--accent-foreground)}
.dup{border-color:var(--accent);background:var(--primary-soft)}
@media(max-width:860px){.admin{grid-template-columns:1fr}.admin-nav{position:static}.fila-2{grid-template-columns:1fr}}
@media(max-width:760px){
  .hero{min-height:340px}.hero h1{font-size:30px}
  .buscador{flex-direction:column;align-items:stretch;border-radius:var(--radio)}
  .buscador .sep{display:none}
  .buscador .campo{border-bottom:1px solid var(--border)}
  .buscador button{margin:6px}
  .estilo{flex:0 0 210px;height:150px}
  .busqueda{grid-template-columns:1fr}
  .mapa-lado{position:static}
  .filtros{grid-template-columns:1fr 1fr}
}
`;function k({children:a}){return(0,d.jsxs)("html",{lang:"es",className:`${f().variable} ${h().variable}`,children:[(0,d.jsxs)("head",{children:[(0,d.jsx)("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),(0,d.jsx)("style",{dangerouslySetInnerHTML:{__html:j}})]}),(0,d.jsxs)("body",{children:[(0,d.jsx)("header",{className:"cab",children:(0,d.jsxs)("div",{className:"wrap cab-in",children:[(0,d.jsx)("a",{href:"/",className:"marca",children:"hestiat"}),(0,d.jsx)("a",{href:"/search",style:{color:"var(--muted-fg)",fontSize:14},children:"Explorar"}),(0,d.jsx)("a",{href:"/experiencias",style:{color:"var(--muted-fg)",fontSize:14},children:"Experiencias"}),(0,d.jsx)("button",{className:"cab-btn",children:"Publica tu espacio"})]})}),a,(0,d.jsx)("footer",{children:(0,d.jsx)("div",{className:"wrap",children:"Hestiat 2.0 \xb7 datos del esquema nuevo migrado desde la base original \xb7 sin cargos ocultos"})})]})]})}},23498:()=>{},28445:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,3991,23))},37342:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81170,23)),Promise.resolve().then(c.t.bind(c,23597,23)),Promise.resolve().then(c.t.bind(c,36893,23)),Promise.resolve().then(c.t.bind(c,89748,23)),Promise.resolve().then(c.t.bind(c,6060,23)),Promise.resolve().then(c.t.bind(c,7184,23)),Promise.resolve().then(c.t.bind(c,69576,23)),Promise.resolve().then(c.t.bind(c,73041,23)),Promise.resolve().then(c.t.bind(c,51384,23))},58301:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,65169,23))},86945:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>j,dynamic:()=>i});var d=c(75338),e=c(65169),f=c.n(e),g=c(82161),h=c(6462);let i="force-dynamic";async function j({children:a}){let b=await (0,h.ZT)();return b||(0,g.redirect)("/login?redirect=/admin"),(0,d.jsxs)("div",{className:"admin",children:[(0,d.jsxs)("aside",{className:"admin-nav",children:[(0,d.jsx)("p",{className:"admin-marca",children:"Administraci\xf3n"}),(0,d.jsx)("nav",{children:[["/admin","Resumen"],["/admin/alojamientos","Alojamientos"],["/admin/usuarios","Usuarios"],["/admin/reservas","Reservas"],["/admin/auditoria","Auditor\xeda"]].map(([a,b])=>(0,d.jsx)(f(),{href:a,children:b},a))}),(0,d.jsxs)("p",{className:"admin-sesion",children:[b.email,(0,d.jsx)("br",{}),(0,d.jsxs)("span",{style:{color:"var(--muted-fg)"},children:["rol: ",b.rol]})]})]}),(0,d.jsx)("section",{className:"admin-main",children:a})]})}}};